import AccordionFunc from "../../components/accordion/Accordion"

function Diktant() {
  return (
    <div className="w-full min-h-[100vh] p-12  border-b-[1px] border-b-black">
      <AccordionFunc />
    </div>
  );
}

export default Diktant
